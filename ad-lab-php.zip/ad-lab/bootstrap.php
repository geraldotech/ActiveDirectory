<?php
declare(strict_types=1);

/**
 * Bootstrap: autoloader PSR-4 (App\ -> src/) e helpers globais.
 */

define('BASE_PATH', __DIR__);

// Base publica do app: '' com docroot dedicado (Docker),
// '/ad-lab' quando instalado em subdiretorio (XAMPP com rewrite para public/)
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
define('APP_BASE', basename($scriptDir) === 'public' ? rtrim(dirname($scriptDir), '/') : $scriptDir);
unset($scriptDir);

spl_autoload_register(function (string $classe): void {
    $prefixo = 'App\\';
    if (!str_starts_with($classe, $prefixo)) {
        return;
    }
    $arquivo = BASE_PATH . '/src/' . str_replace('\\', '/', substr($classe, strlen($prefixo))) . '.php';
    if (is_file($arquivo)) {
        require $arquivo;
    }
});

if (!function_exists('h')) {
    /** Escape para HTML (usar em todas as views). */
    function h(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('base_url')) {
    /** URL relativa a raiz publica do app (sem expor /public). */
    function base_url(string $caminho = '/'): string
    {
        return APP_BASE . '/' . ltrim($caminho, '/');
    }
}

// Fora do Docker (ex.: XAMPP), aceita o certificado autoassinado do Samba.
if (getenv('LDAPTLS_REQCERT') === false) {
    putenv('LDAPTLS_REQCERT=never');
}
