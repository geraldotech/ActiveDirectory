<?php
declare(strict_types=1);

/**
 * Front controller: todas as requisicoes passam por aqui.
 */

require dirname(__DIR__) . '/bootstrap.php';

use App\Controller\UsuarioController;
use App\Core\Router;

$router = new Router();

$router->get('/', fn() => (new UsuarioController())->form());
$router->get('/usuarios', fn() => (new UsuarioController())->lista());
$router->get('/usuarios/editar', fn() => (new UsuarioController())->editar());
$router->post('/usuarios/criar', fn() => (new UsuarioController())->criar());
$router->post('/usuarios/atualizar', fn() => (new UsuarioController())->atualizar());
$router->post('/usuarios/bloquear', fn() => (new UsuarioController())->bloquear());
$router->post('/usuarios/senha', fn() => (new UsuarioController())->senha());

$router->despachar($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/');
