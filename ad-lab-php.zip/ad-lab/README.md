# Laboratório Active Directory no Docker (Mac)

Ambiente completo: Samba AD DC (domínio **corp.a2solutions.com.br**) + tela em PHP para criar usuários com seleção de OU e grupos.

O app PHP segue **MVC** (sem framework, sem dependências). Nesta instalação o PHP roda no **XAMPP** e só o AD roda no Docker — compose em `~/ad-lab-docker`. A versão 100% Docker (com container PHP) está no `ad-lab.zip` original.

```
ad-lab/
├── .htaccess                # rewrite raiz -> public/ (esconde /public da URL)
├── public/
│   ├── index.php            # front controller (router)
│   └── .htaccess            # rewrite para o front controller
├── bootstrap.php            # autoloader (App\ -> src/) + APP_BASE
├── cli.php                  # criação de usuário via terminal
├── config/
│   ├── config.php           # configuração (lê variáveis de ambiente)
│   └── config.local.php     # valores para rodar no XAMPP
└── src/
    ├── Core/                # Router, View, Config
    ├── Controller/
    │   └── UsuarioController.php
    ├── Model/               # AdConexao, UsuarioModel, OuModel, GrupoModel
    └── View/
        ├── layout.php
        └── usuario/form.php
```

Rotas: `GET /` (formulário) e `POST /usuarios/criar` (criação).

## 1. Instalar o Docker no MacBook

**Opção A — Homebrew:**

```bash
brew install --cask docker
```

**Opção B — download:** baixe o Docker Desktop em <https://www.docker.com/products/docker-desktop/> (escolha *Apple Silicon* ou *Intel*) e arraste para Aplicativos.

Depois, abra o **Docker.app**, aguarde o ícone da baleia ficar estável e confira:

```bash
docker --version
docker compose version
```

A imagem do AD (`diegogslomp/samba-ad-dc`) é multi-arch — funciona nativamente em Apple Silicon (M1–M4) e Intel.

## 2. Subir o ambiente

```bash
cd ad-lab
docker compose up -d --build
```

Na primeira subida o Samba provisiona o domínio (1–3 min). Acompanhe com `docker compose logs -f dc1`.

## 3. Criar as OUs e grupos de exemplo

```bash
docker compose exec dc1 bash /provision/provision.sh
```

Cria as OUs **TI, Financeiro, Comercial, RH, Grupos** e os grupos **GRP_TI, GRP_FINANCEIRO, GRP_COMERCIAL, GRP_RH, GRP_VPN, GRP_ERP**. O script espera o DC ficar pronto e pode ser executado de novo sem duplicar nada.

## 4. Usar a tela de cadastro

Abra **<http://localhost:8080>**. Os selects de OU e de grupos são carregados do AD em tempo real — qualquer OU/grupo novo criado no domínio aparece automaticamente. A criação usa LDAPS (obrigatório para definir senha no AD).

## 5. Criar usuário pelo terminal (opcional)

```bash
docker compose exec app php cli.php \
  --nome=Joao --sobrenome=Silva --login=joao.silva --senha='Mudar@123' \
  --ou='OU=TI,DC=corp,DC=a2solutions,DC=com,DC=br' \
  --grupo='CN=GRP_TI,OU=Grupos,DC=corp,DC=a2solutions,DC=com,DC=br' \
  --trocar-senha
```

## Comandos úteis

```bash
docker compose exec dc1 samba-tool user list
docker compose exec dc1 samba-tool group listmembers GRP_TI
docker compose exec dc1 samba-tool user delete joao.silva
docker compose exec dc1 samba-tool domain passwordsettings show
docker compose down -v        # apaga TUDO e recomeça do zero
```

## Política de senha

O domínio exige senha com no mínimo 7 caracteres e complexidade (maiúscula + minúscula + número/símbolo). Para relaxar em laboratório:

```bash
docker compose exec dc1 samba-tool domain passwordsettings set --complexity=off --min-pwd-length=6
```

## Rodar o app no XAMPP (em vez do container PHP)

O AD continua no Docker; só o PHP roda no Apache do XAMPP:

1. Projeto em `/Applications/XAMPP/xamppfiles/htdocs/ad-lab`.
2. Suba só o DC: `docker compose up -d dc1` (a porta 636 já fica publicada no Mac).
3. Confirme a extensão ldap no PHP do XAMPP: `/Applications/XAMPP/xamppfiles/bin/php -m | grep ldap` (requer PHP ≥ 8.1).
4. Acesse **<http://localhost/ad-lab/>**.

A conexão usa `config/config.local.php` (`ldaps://localhost:636`) — dentro do Docker esse arquivo é ignorado, pois as variáveis de ambiente têm precedência. O app detecta o subdiretório automaticamente (`base_url`).

## Apontar para um AD real

Basta trocar as variáveis do serviço `app` no `docker-compose.yml` (`AD_URI`, `AD_BASE_DN`, `AD_BIND_DN`, `AD_BIND_PASS`, `AD_UPN_SUFFIX`) para o seu DC de produção, usando uma conta de serviço com permissão de criação de usuários. Em produção, remova o `TLS_REQCERT never` do `php/Dockerfile` e instale o certificado da CA do domínio.

## Avisos

O `.env` guarda a senha do Administrator em texto puro e a tela não tem autenticação — é um ambiente de **laboratório**; não exponha a porta 8080 fora da sua máquina.
