<?php
declare(strict_types=1);

/**
 * Criacao de usuario no AD via linha de comando (usa os mesmos Models do MVC).
 *
 * Uso:
 *   docker compose exec app php cli.php \
 *     --nome=Joao --sobrenome=Silva --login=joao.silva --senha='Mudar@123' \
 *     [--email=joao@a2solutions.com.br] \
 *     [--ou='OU=TI,DC=corp,DC=a2solutions,DC=com,DC=br'] \
 *     [--grupo='CN=GRP_TI,OU=Grupos,DC=corp,DC=a2solutions,DC=com,DC=br'] \
 *     [--grupo='...outro grupo...'] [--trocar-senha]
 */

if (PHP_SAPI !== 'cli') {
    exit("Somente via linha de comando.\n");
}

require __DIR__ . '/bootstrap.php';

use App\Core\Config;
use App\Model\AdConexao;
use App\Model\UsuarioModel;

$opts = getopt('', ['nome:', 'sobrenome:', 'login:', 'senha:', 'email::', 'ou::', 'grupo::', 'trocar-senha']);

foreach (['nome', 'sobrenome', 'login', 'senha'] as $obrigatorio) {
    if (empty($opts[$obrigatorio]) || !is_string($opts[$obrigatorio])) {
        fwrite(STDERR, "Parametro obrigatorio: --{$obrigatorio}\n");
        exit(1);
    }
}

$grupos = [];
if (isset($opts['grupo'])) {
    $grupos = is_array($opts['grupo']) ? $opts['grupo'] : [$opts['grupo']];
}

try {
    $ad = new AdConexao();
    $dn = (new UsuarioModel($ad))->criar([
        'nome'         => (string)$opts['nome'],
        'sobrenome'    => (string)$opts['sobrenome'],
        'login'        => (string)$opts['login'],
        'senha'        => (string)$opts['senha'],
        'email'        => isset($opts['email']) && is_string($opts['email']) ? $opts['email'] : '',
        'ou_dn'        => isset($opts['ou']) && is_string($opts['ou']) && $opts['ou'] !== ''
                            ? $opts['ou']
                            : 'CN=Users,' . Config::get('base_dn'),
        'grupos'       => $grupos,
        'trocar_senha' => array_key_exists('trocar-senha', $opts),
    ]);
    echo "Usuario criado: {$dn}\n";
    if ($grupos) {
        echo 'Adicionado a ' . count($grupos) . " grupo(s).\n";
    }
} catch (Throwable $e) {
    fwrite(STDERR, 'ERRO: ' . $e->getMessage() . "\n");
    exit(1);
}
