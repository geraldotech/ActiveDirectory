<?php
declare(strict_types=1);

namespace App\Core;

final class View
{
    /**
     * Renderiza uma view dentro do layout.
     * As chaves de $dados viram variaveis na view ($ous, $msg, ...).
     */
    public static function render(string $view, array $dados = []): void
    {
        extract($dados, EXTR_SKIP);

        ob_start();
        require BASE_PATH . '/src/View/' . $view . '.php';
        $conteudo = ob_get_clean();

        $titulo = $dados['titulo'] ?? 'Active Directory';
        require BASE_PATH . '/src/View/layout.php';
    }
}
