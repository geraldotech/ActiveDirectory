<?php
declare(strict_types=1);

namespace App\Core;

final class Config
{
    private static ?array $dados = null;

    public static function todas(): array
    {
        return self::$dados ??= require BASE_PATH . '/config/config.php';
    }

    public static function get(string $chave, mixed $padrao = null): mixed
    {
        return self::todas()[$chave] ?? $padrao;
    }
}
