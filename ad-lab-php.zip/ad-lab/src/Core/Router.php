<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    /** @var array<string, array<string, callable>> */
    private array $rotas = [];

    public function get(string $caminho, callable $acao): void
    {
        $this->rotas['GET'][$caminho] = $acao;
    }

    public function post(string $caminho, callable $acao): void
    {
        $this->rotas['POST'][$caminho] = $acao;
    }

    public function despachar(string $metodo, string $uri): void
    {
        $caminho = parse_url($uri, PHP_URL_PATH) ?: '/';

        // Remove o prefixo do subdiretorio (ex.: /ad-lab no XAMPP)
        if (defined('APP_BASE') && APP_BASE !== '' && str_starts_with($caminho, APP_BASE)) {
            $caminho = substr($caminho, strlen(APP_BASE)) ?: '/';
        }

        // Suporta acesso direto a /public e sem mod_rewrite (/index.php/rota)
        foreach (['/public', '/index.php'] as $prefixo) {
            if (str_starts_with($caminho, $prefixo)) {
                $caminho = substr($caminho, strlen($prefixo)) ?: '/';
            }
        }
        $caminho = rtrim($caminho, '/') ?: '/';

        $acao = $this->rotas[strtoupper($metodo)][$caminho] ?? null;
        if ($acao === null) {
            http_response_code(404);
            echo '404 - rota nao encontrada';
            return;
        }
        $acao();
    }
}
