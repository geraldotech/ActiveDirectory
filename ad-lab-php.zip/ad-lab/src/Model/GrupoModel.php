<?php
declare(strict_types=1);

namespace App\Model;

final class GrupoModel
{
    public function __construct(private AdConexao $ad)
    {
    }

    /**
     * Lista os grupos do dominio.
     * @return array<int, array{dn: string, label: string}>
     */
    public function listar(): array
    {
        $entradas = $this->ad->buscar('(objectClass=group)', ['cn']);

        $grupos = [];
        for ($i = 0; $i < $entradas['count']; $i++) {
            $grupos[] = [
                'dn'    => $entradas[$i]['dn'],
                'label' => $entradas[$i]['cn'][0] ?? $entradas[$i]['dn'],
            ];
        }
        usort($grupos, fn($a, $b) => strcasecmp($a['label'], $b['label']));
        return $grupos;
    }
}
