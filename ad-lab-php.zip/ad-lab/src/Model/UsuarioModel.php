<?php
declare(strict_types=1);

namespace App\Model;

use App\Core\Config;

final class UsuarioModel
{
    public function __construct(private AdConexao $ad)
    {
    }

    /**
     * Cria um usuario no AD e o adiciona aos grupos informados.
     *
     * $dados: nome, sobrenome, login, senha, email (opcional),
     *         ou_dn, grupos (array de DNs), trocar_senha (bool)
     *
     * @return string DN do usuario criado
     */
    public function criar(array $dados): string
    {
        $conn = $this->ad->bruta();

        // Verifica se o login ja existe no dominio
        if ($this->loginExiste($dados['login'])) {
            throw new \RuntimeException("O login '{$dados['login']}' ja esta em uso no dominio.");
        }

        $cn = trim($dados['nome'] . ' ' . $dados['sobrenome']);
        $dn = 'CN=' . ldap_escape($cn, '', LDAP_ESCAPE_DN) . ',' . $dados['ou_dn'];
        $upn = $dados['login'] . '@' . Config::get('upn_suffix');

        // unicodePwd: senha entre aspas duplas, em UTF-16LE, via conexao segura (LDAPS)
        $unicodePwd = iconv('UTF-8', 'UTF-16LE', '"' . $dados['senha'] . '"');

        $entrada = [
            'objectClass'        => ['top', 'person', 'organizationalPerson', 'user'],
            'cn'                 => $cn,
            'givenName'          => $dados['nome'],
            'sn'                 => $dados['sobrenome'],
            'displayName'        => $cn,
            'sAMAccountName'     => $dados['login'],
            'userPrincipalName'  => $upn,
            'unicodePwd'         => $unicodePwd,
            'userAccountControl' => '512', // NORMAL_ACCOUNT, habilitado
        ];
        if (!empty($dados['email'])) {
            $entrada['mail'] = $dados['email'];
        }

        // Campos organizacionais opcionais -> atributos do AD
        $opcionais = [
            'cargo'        => 'title',
            'departamento' => 'department',
            'empresa'      => 'company',
            'telefone'     => 'telephoneNumber',
            'celular'      => 'mobile',
            'matricula'    => 'employeeID',
            'descricao'    => 'description',
            'gestor_dn'    => 'manager',
        ];
        foreach ($opcionais as $chave => $atributo) {
            if (!empty($dados[$chave])) {
                $entrada[$atributo] = $dados[$chave];
            }
        }

        // accountExpires: data (Y-m-d) -> FILETIME (intervalos de 100ns desde 1601-01-01 UTC)
        if (!empty($dados['expira_em'])) {
            $ts = strtotime($dados['expira_em'] . ' 23:59:59 UTC');
            if ($ts !== false) {
                $entrada['accountExpires'] = (string)(($ts + 11644473600) * 10000000);
            }
        }

        if (!@ldap_add($conn, $dn, $entrada)) {
            throw new \RuntimeException('Falha ao criar o usuario: ' . $this->ad->erro());
        }

        // Forca troca de senha no primeiro logon
        if (!empty($dados['trocar_senha'])) {
            @ldap_mod_replace($conn, $dn, ['pwdLastSet' => '0']);
        }

        // Adiciona aos grupos selecionados
        foreach ($dados['grupos'] as $grupoDn) {
            if (!@ldap_mod_add($conn, $grupoDn, ['member' => $dn])) {
                throw new \RuntimeException(
                    "Usuario criado ({$dn}), mas houve falha ao adicionar ao grupo {$grupoDn}: " . $this->ad->erro()
                );
            }
        }

        return $dn;
    }

    /**
     * Lista os usuarios do dominio (para o select de gestor).
     * @return array<int, array{dn: string, label: string}>
     */
    public function listar(): array
    {
        $entradas = $this->ad->buscar('(&(objectClass=user)(objectCategory=person))', ['cn']);
        $usuarios = [];
        for ($i = 0; $i < $entradas['count']; $i++) {
            $usuarios[] = [
                'dn'    => $entradas[$i]['dn'],
                'label' => $entradas[$i]['cn'][0] ?? $entradas[$i]['dn'],
            ];
        }
        usort($usuarios, fn($a, $b) => strcasecmp($a['label'], $b['label']));
        return $usuarios;
    }

    /** Verifica se ja existe usuario com este sAMAccountName. */
    public function loginExiste(string $login): bool
    {
        $filtro = '(sAMAccountName=' . ldap_escape($login, '', LDAP_ESCAPE_FILTER) . ')';
        $res = $this->ad->buscar($filtro, ['sAMAccountName']);
        return ($res['count'] ?? 0) > 0;
    }

    /**
     * Lista com detalhes para a aba Usuarios (inclui status de bloqueio).
     * @return array<int, array<string, mixed>>
     */
    public function listarDetalhado(): array
    {
        $attrs = [
            'sAMAccountName', 'cn', 'mail', 'title', 'department', 'userAccountControl',
            'accountExpires', 'whenCreated', 'whenChanged',
        ];
        $entradas = $this->ad->buscar('(&(objectClass=user)(objectCategory=person))', $attrs);

        $usuarios = [];
        for ($i = 0; $i < $entradas['count']; $i++) {
            $e = $entradas[$i];
            $uac = (int)($e['useraccountcontrol'][0] ?? 0);
            $usuarios[] = [
                'dn'           => $e['dn'],
                'login'        => $e['samaccountname'][0] ?? '',
                'nome'         => $e['cn'][0] ?? '',
                'email'        => $e['mail'][0] ?? '',
                'cargo'        => $e['title'][0] ?? '',
                'departamento' => $e['department'][0] ?? '',
                'bloqueado'    => ($uac & 2) === 2, // bit ACCOUNTDISABLE
                'validade'     => self::filetimeParaDataBr($e['accountexpires'][0] ?? '0'),
                'criado_em'    => self::ldapTimeParaDataBr($e['whencreated'][0] ?? null),
                'alterado_em'  => self::ldapTimeParaDataBr($e['whenchanged'][0] ?? null),
            ];
        }
        usort($usuarios, fn($a, $b) => strcasecmp($a['nome'], $b['nome']));
        return $usuarios;
    }

    /** FILETIME do AD -> dd/mm/aaaa ('' = nunca expira). */
    private static function filetimeParaDataBr(string $ft): string
    {
        if ($ft === '' || $ft === '0' || $ft === '9223372036854775807') {
            return '';
        }
        $ts = intdiv((int)$ft, 10000000) - 11644473600;
        return gmdate('d/m/Y', $ts);
    }

    /** GeneralizedTime do LDAP (aaaammddhhmmss.0Z) -> dd/mm/aaaa hh:mm no horario de Brasilia. */
    private static function ldapTimeParaDataBr(?string $t): string
    {
        if ($t === null || $t === '') {
            return '';
        }
        $dt = \DateTime::createFromFormat('YmdHis.0\Z', $t, new \DateTimeZone('UTC'));
        if ($dt === false) {
            return '';
        }
        $dt->setTimezone(new \DateTimeZone('America/Sao_Paulo'));
        return $dt->format('d/m/Y H:i');
    }

    /** Busca um usuario pelo login, com todos os campos editaveis. */
    public function buscarPorLogin(string $login): ?array
    {
        $filtro = '(&(objectClass=user)(sAMAccountName=' . ldap_escape($login, '', LDAP_ESCAPE_FILTER) . '))';
        $attrs = [
            'sAMAccountName', 'givenName', 'sn', 'mail', 'title', 'department', 'company',
            'telephoneNumber', 'mobile', 'employeeID', 'description', 'manager',
            'accountExpires', 'userAccountControl',
        ];
        $res = $this->ad->buscar($filtro, $attrs);
        if (($res['count'] ?? 0) === 0) {
            return null;
        }
        $e = $res[0];

        // accountExpires (FILETIME) -> Y-m-d ('' = nunca expira)
        $expira = '';
        $ft = $e['accountexpires'][0] ?? '0';
        if ($ft !== '0' && $ft !== '9223372036854775807') {
            $expira = gmdate('Y-m-d', intdiv((int)$ft, 10000000) - 11644473600);
        }

        [, $ouAtual] = self::dividirDn($e['dn']);

        return [
            'dn'           => $e['dn'],
            'ou_dn'        => $ouAtual,
            'login'        => $e['samaccountname'][0] ?? '',
            'nome'         => $e['givenname'][0] ?? '',
            'sobrenome'    => $e['sn'][0] ?? '',
            'email'        => $e['mail'][0] ?? '',
            'cargo'        => $e['title'][0] ?? '',
            'departamento' => $e['department'][0] ?? '',
            'empresa'      => $e['company'][0] ?? '',
            'telefone'     => $e['telephonenumber'][0] ?? '',
            'celular'      => $e['mobile'][0] ?? '',
            'matricula'    => $e['employeeid'][0] ?? '',
            'descricao'    => $e['description'][0] ?? '',
            'gestor_dn'    => $e['manager'][0] ?? '',
            'expira_em'    => $expira,
            'bloqueado'    => (((int)($e['useraccountcontrol'][0] ?? 0)) & 2) === 2,
        ];
    }

    /** Atualiza os atributos editaveis (campo vazio remove o atributo no AD). */
    public function atualizar(string $dn, array $dados): void
    {
        $conn = $this->ad->bruta();

        $mods = [
            'givenName'       => $dados['nome'],
            'sn'              => $dados['sobrenome'],
            'displayName'     => trim($dados['nome'] . ' ' . $dados['sobrenome']),
            'mail'            => $dados['email'],
            'title'           => $dados['cargo'],
            'department'      => $dados['departamento'],
            'company'         => $dados['empresa'],
            'telephoneNumber' => $dados['telefone'],
            'mobile'          => $dados['celular'],
            'employeeID'      => $dados['matricula'],
            'description'     => $dados['descricao'],
            'manager'         => $dados['gestor_dn'],
        ];
        // Le o estado atual para saber quais atributos existem no objeto
        $atuais = $this->ad->ler($dn, array_keys($mods)) ?? [];

        // PHP 8 nao aceita array vazio no ldap_mod_replace; usa-se
        // ldap_modify_batch: REPLACE para valores e REMOVE_ALL para limpar.
        $batch = [];
        foreach ($mods as $atributo => $valor) {
            if ($valor !== '') {
                $batch[] = [
                    'attrib'  => $atributo,
                    'modtype' => LDAP_MODIFY_BATCH_REPLACE,
                    'values'  => [$valor],
                ];
            } elseif (isset($atuais[strtolower($atributo)])) {
                // campo esvaziado na tela e existente no AD -> remove
                $batch[] = [
                    'attrib'  => $atributo,
                    'modtype' => LDAP_MODIFY_BATCH_REMOVE_ALL,
                ];
            }
            // vazio e inexistente no AD -> nada a fazer
        }

        $expira = '0'; // nunca expira
        if (!empty($dados['expira_em'])) {
            $ts = strtotime($dados['expira_em'] . ' 23:59:59 UTC');
            if ($ts !== false) {
                $expira = (string)(($ts + 11644473600) * 10000000);
            }
        }
        $batch[] = [
            'attrib'  => 'accountExpires',
            'modtype' => LDAP_MODIFY_BATCH_REPLACE,
            'values'  => [$expira],
        ];

        if (!@ldap_modify_batch($conn, $dn, $batch)) {
            throw new \RuntimeException('Falha ao atualizar o usuario: ' . $this->ad->erro());
        }
    }

    /**
     * Move o usuario para outra OU (ldap_rename). Retorna o novo DN.
     * Nao faz nada se ja estiver na OU de destino.
     */
    public function mover(string $dn, string $novaOuDn): string
    {
        [$rdn, $paiAtual] = self::dividirDn($dn);
        if ($rdn === '' || $paiAtual === '') {
            throw new \RuntimeException('DN invalido: ' . $dn);
        }
        if (strcasecmp($paiAtual, $novaOuDn) === 0) {
            return $dn; // ja esta na OU
        }

        $conn = $this->ad->bruta();
        if (!@ldap_rename($conn, $dn, $rdn, $novaOuDn, true)) {
            throw new \RuntimeException('Falha ao mover o usuario de OU: ' . $this->ad->erro());
        }
        return $rdn . ',' . $novaOuDn;
    }

    /** Divide um DN em [RDN, DN do pai], respeitando virgulas escapadas. */
    private static function dividirDn(string $dn): array
    {
        $tam = strlen($dn);
        $rdn = '';
        for ($i = 0; $i < $tam; $i++) {
            if ($dn[$i] === '\\') {
                $rdn .= $dn[$i] . ($dn[$i + 1] ?? '');
                $i++;
                continue;
            }
            if ($dn[$i] === ',') {
                break;
            }
            $rdn .= $dn[$i];
        }
        return [$rdn, substr($dn, $i + 1)];
    }

    /**
     * DNs dos grupos dos quais o usuario e membro (exceto o grupo primario, ex.: Domain Users).
     * @return string[]
     */
    public function gruposDoUsuario(string $userDn): array
    {
        $filtro = '(&(objectClass=group)(member=' . ldap_escape($userDn, '', LDAP_ESCAPE_FILTER) . '))';
        $res = $this->ad->buscar($filtro, ['cn']);
        $dns = [];
        for ($i = 0; $i < $res['count']; $i++) {
            $dns[] = $res[$i]['dn'];
        }
        return $dns;
    }

    /** Sincroniza os grupos do usuario: adiciona nos novos e remove dos desmarcados. */
    public function definirGrupos(string $userDn, array $desejados): void
    {
        $conn = $this->ad->bruta();
        $atuais = $this->gruposDoUsuario($userDn);

        $lcAtuais    = array_map('strtolower', $atuais);
        $lcDesejados = array_map('strtolower', array_values($desejados));

        foreach (array_values($desejados) as $i => $dnGrupo) {
            if (!in_array($lcDesejados[$i], $lcAtuais, true)) {
                if (!@ldap_mod_add($conn, $dnGrupo, ['member' => $userDn])) {
                    throw new \RuntimeException("Falha ao adicionar ao grupo {$dnGrupo}: " . $this->ad->erro());
                }
            }
        }
        foreach ($atuais as $i => $dnGrupo) {
            if (!in_array($lcAtuais[$i], $lcDesejados, true)) {
                if (!@ldap_mod_del($conn, $dnGrupo, ['member' => $userDn])) {
                    throw new \RuntimeException("Falha ao remover do grupo {$dnGrupo}: " . $this->ad->erro());
                }
            }
        }
    }

    /** Redefine a senha do usuario (reset administrativo, requer LDAPS). */
    public function redefinirSenha(string $dn, string $novaSenha, bool $trocarNoLogon = false): void
    {
        $conn = $this->ad->bruta();

        $unicodePwd = iconv('UTF-8', 'UTF-16LE', '"' . $novaSenha . '"');
        if (!@ldap_mod_replace($conn, $dn, ['unicodePwd' => $unicodePwd])) {
            throw new \RuntimeException('Falha ao redefinir a senha: ' . $this->ad->erro());
        }
        if ($trocarNoLogon) {
            @ldap_mod_replace($conn, $dn, ['pwdLastSet' => '0']);
        }
    }

    /** Bloqueia ou desbloqueia a conta (bit ACCOUNTDISABLE do userAccountControl). */
    public function definirBloqueio(string $dn, bool $bloquear): void
    {
        $conn = $this->ad->bruta();

        $atual = $this->ad->ler($dn, ['userAccountControl']);
        if ($atual === null) {
            throw new \RuntimeException('Usuario nao encontrado: ' . $dn);
        }
        $uac = (int)($atual['useraccountcontrol'][0] ?? 512);
        $novo = $bloquear ? ($uac | 2) : ($uac & ~2);

        if (!@ldap_mod_replace($conn, $dn, ['userAccountControl' => (string)$novo])) {
            throw new \RuntimeException('Falha ao alterar o bloqueio: ' . $this->ad->erro());
        }
    }
}
