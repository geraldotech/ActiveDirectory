<?php
declare(strict_types=1);

namespace App\Model;

use App\Core\Config;

/**
 * Conexao LDAPS autenticada com o Active Directory.
 */
final class AdConexao
{
    /** @var \LDAP\Connection */
    private $conn;

    public function __construct()
    {
        $cfg = Config::todas();

        // Laboratorio: aceita o certificado autoassinado do Samba.
        // Precisa ser GLOBAL (link = null) e ANTES do ldap_connect,
        // senao a libldap ignora. Em producao, remova e instale a CA do dominio.
        if (defined('LDAP_OPT_X_TLS_REQUIRE_CERT')) {
            ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, LDAP_OPT_X_TLS_NEVER);
        }

        $conn = ldap_connect($cfg['uri']);
        if ($conn === false) {
            throw new \RuntimeException('URI LDAP invalida: ' . $cfg['uri']);
        }
        ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);
        ldap_set_option($conn, LDAP_OPT_NETWORK_TIMEOUT, 5);

        if (!@ldap_bind($conn, $cfg['bind_dn'], $cfg['bind_pass'])) {
            throw new \RuntimeException('Falha ao conectar/autenticar no AD: ' . $this->erroDe($conn));
        }
        $this->conn = $conn;
    }

    /** @return \LDAP\Connection */
    public function bruta()
    {
        return $this->conn;
    }

    /** Busca no base DN e retorna as entradas (formato ldap_get_entries). */
    public function buscar(string $filtro, array $atributos): array
    {
        $res = ldap_search($this->conn, Config::get('base_dn'), $filtro, $atributos);
        if ($res === false) {
            throw new \RuntimeException('Falha na busca LDAP: ' . $this->erro());
        }
        return ldap_get_entries($this->conn, $res);
    }

    /** Le um objeto especifico pelo DN. Retorna a entrada ou null. */
    public function ler(string $dn, array $atributos): ?array
    {
        $res = @ldap_read($this->conn, $dn, '(objectClass=*)', $atributos);
        if ($res === false) {
            return null;
        }
        $entradas = ldap_get_entries($this->conn, $res);
        return ($entradas['count'] ?? 0) > 0 ? $entradas[0] : null;
    }

    /** Erro LDAP atual + diagnostico do AD, traduzido. */
    public function erro(): string
    {
        return $this->erroDe($this->conn);
    }

    private function erroDe($conn): string
    {
        $msg = ldap_error($conn);
        $diag = '';
        ldap_get_option($conn, LDAP_OPT_DIAGNOSTIC_MESSAGE, $diag);
        if ($diag) {
            $msg .= ' (' . $diag . ')';
        }
        return $this->traduz($msg);
    }

    private function traduz(string $msg): string
    {
        if (str_contains($msg, '0000052D') || (stripos($msg, 'password') !== false && stripos($msg, 'constraint') !== false)) {
            return $msg . ' — A senha nao atende a politica do dominio (minimo 7 caracteres, com maiuscula, minuscula e numero/simbolo).';
        }
        if (stripos($msg, 'Already exists') !== false || str_contains($msg, '00002071') || str_contains($msg, '000021C8')) {
            return $msg . ' — Ja existe um objeto com esse nome/login.';
        }
        if (stripos($msg, 'already in use') !== false) {
            return $msg . ' — Login (sAMAccountName) ja em uso no dominio.';
        }
        if (str_contains($msg, '0000208D') || stripos($msg, 'No such object') !== false) {
            return $msg . ' — OU ou grupo nao encontrado no diretorio.';
        }
        return $msg;
    }
}
