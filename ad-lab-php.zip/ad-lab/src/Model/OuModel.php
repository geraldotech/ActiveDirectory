<?php
declare(strict_types=1);

namespace App\Model;

use App\Core\Config;

final class OuModel
{
    public function __construct(private AdConexao $ad)
    {
    }

    /**
     * Lista as OUs do dominio (+ o container padrao CN=Users).
     *
     * Quando o servidor retorna o atributo allowedChildClassesEffective,
     * exibe apenas as OUs onde a conta de servico PODE CRIAR usuarios.
     * Se o atributo nao vier (servidor sem suporte), exibe todas.
     *
     * @return array<int, array{dn: string, label: string}>
     */
    public function listar(): array
    {
        $base = Config::get('base_dn');
        $entradas = $this->ad->buscar(
            '(objectClass=organizationalUnit)',
            ['ou', 'allowedChildClassesEffective']
        );

        $suporteEfetivo = false;
        $candidatas = [];

        for ($i = 0; $i < $entradas['count']; $i++) {
            $e = $entradas[$i];
            $pode = null; // desconhecido (atributo nao retornado)
            if (isset($e['allowedchildclasseseffective'])) {
                $suporteEfetivo = true;
                $pode = in_array('user', self::valores($e['allowedchildclasseseffective']), true);
            }
            $candidatas[] = [
                'dn'    => $e['dn'],
                'label' => $this->rotulo($e['dn'], $base),
                'pode'  => $pode,
            ];
        }

        // Container padrao CN=Users
        $usersDn = 'CN=Users,' . $base;
        $u = $this->ad->ler($usersDn, ['allowedChildClassesEffective']);
        $podeUsers = null;
        if ($u !== null && isset($u['allowedchildclasseseffective'])) {
            $suporteEfetivo = true;
            $podeUsers = in_array('user', self::valores($u['allowedchildclasseseffective']), true);
        }
        $candidatas[] = ['dn' => $usersDn, 'label' => 'Users (container padrao)', 'pode' => $podeUsers];

        // Com suporte do servidor: so OUs com permissao de criar usuario.
        // Sem suporte: exibe todas (fallback).
        $ous = [];
        foreach ($candidatas as $c) {
            if (!$suporteEfetivo || $c['pode'] === true) {
                $ous[] = ['dn' => $c['dn'], 'label' => $c['label']];
            }
        }

        usort($ous, fn($a, $b) => strcasecmp($a['label'], $b['label']));
        return $ous;
    }

    /** Converte o array de atributo do ldap_get_entries em lista de strings minusculas. */
    private static function valores(array $attr): array
    {
        $out = [];
        $n = (int)($attr['count'] ?? 0);
        for ($i = 0; $i < $n; $i++) {
            $out[] = strtolower((string)$attr[$i]);
        }
        return $out;
    }

    /** Rotulo legivel: "TI" ou "Suporte / TI" para OUs aninhadas. */
    private function rotulo(string $dn, string $base): string
    {
        $rel = substr($dn, 0, strlen($dn) - strlen($base) - 1);
        $partes = array_map(
            fn($p) => preg_replace('/^(OU|CN)=/i', '', trim($p)),
            explode(',', $rel)
        );
        return implode(' / ', $partes);
    }
}
