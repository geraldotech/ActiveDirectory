<?php if ($erroConexao !== null): ?>
    <div class="alerta erro">
        Não foi possível conectar ao AD: <?= h($erroConexao) ?><br>
        Verifique se o container <strong>dc1</strong> está no ar
        (<code>docker compose logs -f dc1</code>).
    </div>
<?php else: ?>

<div class="card">
    <h2>Dados do usuário</h2>
    <form method="post" action="<?= h(base_url('/usuarios/criar')) ?>" autocomplete="off">

        <div class="linha">
            <div class="campo">
                <label for="nome">Nome *</label>
                <input type="text" id="nome" name="nome" required maxlength="64">
            </div>
            <div class="campo">
                <label for="sobrenome">Sobrenome *</label>
                <input type="text" id="sobrenome" name="sobrenome" required maxlength="64">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="login">Login (sAMAccountName) *</label>
                <input type="text" id="login" name="login" required maxlength="20"
                       pattern="[A-Za-z0-9._-]{1,20}">
                <div class="dica">Até 20 caracteres. Ex.: joao.silva</div>
            </div>
            <div class="campo">
                <label for="email">E-mail <span class="opc">(opcional)</span></label>
                <input type="email" id="email" name="email" maxlength="120">
            </div>
        </div>

        <div class="campo">
            <label for="senha">Senha *</label>
            <input type="password" id="senha" name="senha" required minlength="7">
            <div class="dica">Mínimo 7 caracteres, com maiúscula, minúscula e número/símbolo (política do domínio).</div>
        </div>

        <div class="check">
            <input type="checkbox" id="trocar_senha" name="trocar_senha" value="1" checked>
            <label for="trocar_senha" style="margin:0">Usuário deve trocar a senha no primeiro logon</label>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="ou">OU (Unidade Organizacional) *</label>
                <select id="ou" name="ou" required>
                    <option value="">— selecione —</option>
                    <?php foreach ($ous as $ou): ?>
                        <option value="<?= h($ou['dn']) ?>" title="<?= h($ou['dn']) ?>">
                            <?= h($ou['label']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="dica">Alguma OU não apareceu? O usuário de integração pode não ter permissão de escrita (criação de usuários) nela.</div>
            </div>
            <div class="campo">
                <label for="grupos">Grupos</label>
                <select id="grupos" name="grupos[]" multiple>
                    <?php foreach ($grupos as $g): ?>
                        <option value="<?= h($g['dn']) ?>" title="<?= h($g['dn']) ?>">
                            <?= h($g['label']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="dica">Segure Cmd (Mac) ou Ctrl para selecionar vários.</div>
            </div>
        </div>

        <h2 style="margin-top:24px">Dados organizacionais <span class="opc" style="font-weight:400;font-size:13px">(opcional)</span></h2>

        <div class="linha">
            <div class="campo">
                <label for="cargo">Cargo</label>
                <input type="text" id="cargo" name="cargo" maxlength="64" placeholder="Ex.: Analista de TI">
            </div>
            <div class="campo">
                <label for="departamento">Departamento</label>
                <input type="text" id="departamento" name="departamento" maxlength="64" placeholder="Ex.: TI">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="empresa">Empresa</label>
                <input type="text" id="empresa" name="empresa" maxlength="64" placeholder="Ex.: A2 Solutions">
            </div>
            <div class="campo">
                <label for="matricula">Matrícula</label>
                <input type="text" id="matricula" name="matricula" maxlength="16">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="text" id="telefone" name="telefone" maxlength="32" placeholder="(11) 4000-0000">
            </div>
            <div class="campo">
                <label for="celular">Celular</label>
                <input type="text" id="celular" name="celular" maxlength="32" placeholder="(11) 90000-0000">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="gestor">Gestor</label>
                <select id="gestor" name="gestor">
                    <option value="">— nenhum —</option>
                    <?php foreach ($usuarios as $u): ?>
                        <option value="<?= h($u['dn']) ?>" title="<?= h($u['dn']) ?>">
                            <?= h($u['label']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo">
                <label for="expira_em">Conta expira em</label>
                <input type="date" id="expira_em" name="expira_em">
                <div class="dica">Deixe vazio para nunca expirar (útil p/ terceirizados).</div>
            </div>
        </div>

        <div class="campo">
            <label for="descricao">Descrição</label>
            <input type="text" id="descricao" name="descricao" maxlength="256"
                   placeholder="Ex.: Terceirizado — contrato 2026-042">
        </div>

        <button type="submit">Criar usuário</button>
    </form>
</div>

<?php endif; ?>
