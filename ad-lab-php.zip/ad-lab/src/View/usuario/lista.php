<?php if ($erroConexao !== null): ?>
    <div class="alerta erro">
        Não foi possível conectar ao AD: <?= h($erroConexao) ?><br>
        Verifique se o container <strong>dc1</strong> está no ar
        (<code>docker compose logs -f dc1</code>).
    </div>
<?php else: ?>

<div class="card larga">
    <h2>Usuários do domínio (<?= count($usuarios) ?>)</h2>

    <table class="tabela">
        <thead>
            <tr>
                <th>Login</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Cargo</th>
                <th>Departamento</th>
                <th>Validade</th>
                <th>Criado em</th>
                <th>Alterado em</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($usuarios as $u): ?>
            <?php $protegido = in_array(strtolower($u['login']), ['administrator', 'guest', 'krbtgt'], true); ?>
            <tr>
                <td><?= h($u['login']) ?></td>
                <td title="<?= h($u['dn']) ?>"><?= h($u['nome']) ?></td>
                <td><?= h($u['email']) ?></td>
                <td><?= h($u['cargo']) ?></td>
                <td><?= h($u['departamento']) ?></td>
                <td class="data-col"><?= $u['validade'] !== '' ? h($u['validade']) : '—' ?></td>
                <td class="data-col"><?= $u['criado_em'] !== '' ? h($u['criado_em']) : '—' ?></td>
                <td class="data-col"><?= $u['alterado_em'] !== '' ? h($u['alterado_em']) : '—' ?></td>
                <td>
                    <span class="badge <?= $u['bloqueado'] ? 'vermelho' : 'verde' ?>">
                        <?= $u['bloqueado'] ? 'Bloqueado' : 'Ativo' ?>
                    </span>
                </td>
                <td>
                    <?php if (!$protegido): ?>
                    <div class="acoes">
                        <a class="btn-sm" href="<?= h(base_url('/usuarios/editar?login=' . urlencode($u['login']))) ?>">Editar</a>
                        <form method="post" action="<?= h(base_url('/usuarios/bloquear')) ?>"
                              onsubmit="return confirm('<?= $u['bloqueado'] ? 'Desbloquear' : 'Bloquear' ?> o usuário <?= h($u['login']) ?>?')">
                            <input type="hidden" name="dn" value="<?= h($u['dn']) ?>">
                            <input type="hidden" name="login" value="<?= h($u['login']) ?>">
                            <input type="hidden" name="acao" value="<?= $u['bloqueado'] ? 'desbloquear' : 'bloquear' ?>">
                            <button type="submit" class="btn-sm <?= $u['bloqueado'] ? 'btn-verde' : 'btn-vermelho' ?>"
                                    style="background:#fff">
                                <?= $u['bloqueado'] ? 'Desbloquear' : 'Bloquear' ?>
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php endif; ?>
