<div class="card">
    <h2>
        Editar usuário: <?= h($u['login']) ?>
        <span class="badge <?= $u['bloqueado'] ? 'vermelho' : 'verde' ?>" style="margin-left:8px">
            <?= $u['bloqueado'] ? 'Bloqueado' : 'Ativo' ?>
        </span>
    </h2>

    <form method="post" action="<?= h(base_url('/usuarios/atualizar')) ?>" autocomplete="off">
        <input type="hidden" name="dn" value="<?= h($u['dn']) ?>">
        <input type="hidden" name="login" value="<?= h($u['login']) ?>">

        <div class="linha">
            <div class="campo">
                <label>Login (sAMAccountName)</label>
                <input type="text" value="<?= h($u['login']) ?>" readonly>
            </div>
            <div class="campo">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" maxlength="120" value="<?= h($u['email']) ?>">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="nome">Nome *</label>
                <input type="text" id="nome" name="nome" required maxlength="64" value="<?= h($u['nome']) ?>">
            </div>
            <div class="campo">
                <label for="sobrenome">Sobrenome *</label>
                <input type="text" id="sobrenome" name="sobrenome" required maxlength="64" value="<?= h($u['sobrenome']) ?>">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="cargo">Cargo</label>
                <input type="text" id="cargo" name="cargo" maxlength="64" value="<?= h($u['cargo']) ?>">
            </div>
            <div class="campo">
                <label for="departamento">Departamento</label>
                <input type="text" id="departamento" name="departamento" maxlength="64" value="<?= h($u['departamento']) ?>">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="empresa">Empresa</label>
                <input type="text" id="empresa" name="empresa" maxlength="64" value="<?= h($u['empresa']) ?>">
            </div>
            <div class="campo">
                <label for="matricula">Matrícula</label>
                <input type="text" id="matricula" name="matricula" maxlength="16" value="<?= h($u['matricula']) ?>">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="text" id="telefone" name="telefone" maxlength="32" value="<?= h($u['telefone']) ?>">
            </div>
            <div class="campo">
                <label for="celular">Celular</label>
                <input type="text" id="celular" name="celular" maxlength="32" value="<?= h($u['celular']) ?>">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="ou">OU (Unidade Organizacional)</label>
                <select id="ou" name="ou">
                    <?php foreach ($ous as $ou): ?>
                        <option value="<?= h($ou['dn']) ?>" title="<?= h($ou['dn']) ?>"
                            <?= strcasecmp($ou['dn'], $u['ou_dn']) === 0 ? 'selected' : '' ?>>
                            <?= h($ou['label']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="dica">Alterar move o usuário de OU ao salvar. Alguma OU não apareceu? O usuário de integração pode não ter permissão de escrita nela.</div>
            </div>
            <div class="campo">
                <label for="gestor">Gestor</label>
                <select id="gestor" name="gestor">
                    <option value="">— nenhum —</option>
                    <?php foreach ($usuarios as $opcao): ?>
                        <?php if ($opcao['dn'] === $u['dn']) continue; ?>
                        <option value="<?= h($opcao['dn']) ?>" title="<?= h($opcao['dn']) ?>"
                            <?= strcasecmp($opcao['dn'], $u['gestor_dn']) === 0 ? 'selected' : '' ?>>
                            <?= h($opcao['label']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="expira_em">Conta expira em</label>
                <input type="date" id="expira_em" name="expira_em" value="<?= h($u['expira_em']) ?>">
                <div class="dica">Deixe vazio para nunca expirar.</div>
            </div>
            <div class="campo">
                <label for="descricao">Descrição</label>
                <input type="text" id="descricao" name="descricao" maxlength="256" value="<?= h($u['descricao']) ?>">
            </div>
        </div>

        <div class="linha">
            <div class="campo">
                <label for="grupos">Grupos</label>
                <select id="grupos" name="grupos[]" multiple>
                    <?php foreach ($grupos as $g): ?>
                        <option value="<?= h($g['dn']) ?>" title="<?= h($g['dn']) ?>"
                            <?= in_array(strtolower($g['dn']), $gruposUsuario, true) ? 'selected' : '' ?>>
                            <?= h($g['label']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="dica">Segure Cmd (Mac) ou Ctrl. Desmarcar um grupo remove o usuário dele ao salvar.</div>
            </div>
        </div>

        <div style="display:flex; gap:10px; align-items:center">
            <button type="submit">Salvar alterações</button>
            <a class="btn-sm" href="<?= h(base_url('/usuarios')) ?>" style="padding:10px 20px">Cancelar</a>
        </div>
    </form>
</div>

<div class="card">
    <h2>Redefinir senha</h2>
    <form method="post" action="<?= h(base_url('/usuarios/senha')) ?>" autocomplete="off"
          onsubmit="return confirm('Redefinir a senha de <?= h($u['login']) ?>?')">
        <input type="hidden" name="dn" value="<?= h($u['dn']) ?>">
        <input type="hidden" name="login" value="<?= h($u['login']) ?>">

        <div class="linha">
            <div class="campo">
                <label for="senha">Nova senha *</label>
                <input type="password" id="senha" name="senha" required minlength="7">
                <div class="dica">Mínimo 7 caracteres, com maiúscula, minúscula e número/símbolo (política do domínio).</div>
            </div>
            <div class="campo" style="display:flex; align-items:flex-end">
                <div class="check" style="margin:0 0 22px">
                    <input type="checkbox" id="trocar_senha_reset" name="trocar_senha" value="1" checked>
                    <label for="trocar_senha_reset" style="margin:0">Usuário deve trocar a senha no próximo logon</label>
                </div>
            </div>
        </div>

        <button type="submit">Redefinir senha</button>
    </form>
</div>
