<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($titulo) ?></title>
<style>
    :root {
        --azul: #1a56db; --azul-escuro: #1240a8;
        --fundo: #f3f5f9; --borda: #d6dbe4; --texto: #1f2937;
    }
    * { box-sizing: border-box; }
    body {
        margin: 0; background: var(--fundo); color: var(--texto);
        font: 15px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    .topo {
        background: var(--azul); color: #fff; padding: 18px 28px;
        font-size: 19px; font-weight: 600;
    }
    .topo small { display: block; font-weight: 400; font-size: 13px; opacity: .85; }
    .abas {
        max-width: 980px; margin: 22px auto 0; padding: 0 14px;
        display: flex; gap: 8px;
    }
    .abas a {
        padding: 9px 22px; border-radius: 8px; text-decoration: none;
        font-weight: 600; font-size: 14px; color: var(--texto);
        background: #e4e9f2; border: 1px solid var(--borda);
    }
    .abas a.ativa { background: var(--azul); border-color: var(--azul); color: #fff; }
    .card {
        max-width: 720px; margin: 18px auto 28px; background: #fff;
        border: 1px solid var(--borda); border-radius: 10px; padding: 28px;
    }
    .card.larga { max-width: 1240px; }
    .data-col { white-space: nowrap; font-size: 13px; color: #4b5563; }
    h2 { margin: 0 0 18px; font-size: 17px; }
    .linha { display: flex; gap: 16px; }
    .campo { flex: 1; margin-bottom: 16px; }
    label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 5px; }
    label .opc { font-weight: 400; color: #6b7280; }
    input[type=text], input[type=email], input[type=password], input[type=date], select {
        width: 100%; padding: 9px 11px; border: 1px solid var(--borda);
        border-radius: 6px; font-size: 15px; background: #fff;
    }
    input:focus, select:focus { outline: 2px solid var(--azul); border-color: var(--azul); }
    input[readonly] { background: #f3f5f9; color: #6b7280; }
    select[multiple] { height: 170px; }
    .dica { font-size: 12px; color: #6b7280; margin-top: 4px; }
    .check { display: flex; align-items: center; gap: 8px; margin: 4px 0 18px; }
    .check input { width: 16px; height: 16px; }
    button {
        background: var(--azul); color: #fff; border: 0; border-radius: 6px;
        padding: 11px 26px; font-size: 15px; font-weight: 600; cursor: pointer;
    }
    button:hover { background: var(--azul-escuro); }
    .alerta { max-width: 980px; margin: 18px auto -4px; padding: 13px 16px;
        border-radius: 8px; font-size: 14px; word-break: break-word; }
    .alerta.ok   { background: #def7e4; border: 1px solid #8fd7a3; color: #14532d; }
    .alerta.erro { background: #fde8e8; border: 1px solid #f3b3b3; color: #7f1d1d; }
    .tabela { width: 100%; border-collapse: collapse; font-size: 14px; }
    .tabela th, .tabela td { text-align: left; padding: 9px 10px; border-bottom: 1px solid var(--borda); }
    .tabela th { font-size: 12px; text-transform: uppercase; letter-spacing: .03em; color: #6b7280; }
    .tabela tr:hover td { background: #f8fafc; }
    .badge { padding: 3px 10px; border-radius: 99px; font-size: 12px; font-weight: 600; white-space: nowrap; }
    .badge.verde { background: #def7e4; color: #14532d; }
    .badge.vermelho { background: #fde8e8; color: #7f1d1d; }
    .acoes { display: flex; gap: 6px; align-items: center; }
    .acoes form { margin: 0; }
    .btn-sm {
        display: inline-block; padding: 5px 12px; font-size: 13px; border-radius: 6px;
        border: 1px solid var(--borda); background: #fff; color: var(--texto);
        text-decoration: none; cursor: pointer; font-weight: 600;
    }
    .btn-sm:hover { border-color: var(--azul); color: var(--azul); background: #fff; }
    .btn-sm.btn-vermelho { color: #b91c1c; }
    .btn-sm.btn-vermelho:hover { border-color: #b91c1c; color: #b91c1c; }
    .btn-sm.btn-verde { color: #15803d; }
    .btn-sm.btn-verde:hover { border-color: #15803d; color: #15803d; }
</style>
</head>
<body>

<div class="topo">
    Gestão de Usuários — Active Directory
    <small>Domínio corp.a2solutions.com.br</small>
</div>

<div class="abas">
    <a href="<?= h(base_url('/')) ?>" class="<?= ($abaAtiva ?? '') === 'cadastro' ? 'ativa' : '' ?>">Cadastrar</a>
    <a href="<?= h(base_url('/usuarios')) ?>" class="<?= ($abaAtiva ?? '') === 'usuarios' ? 'ativa' : '' ?>">Usuários</a>
</div>

<?php if (!empty($msg)): ?>
    <div class="alerta <?= ($tipo ?? 'erro') === 'ok' ? 'ok' : 'erro' ?>"><?= h($msg) ?></div>
<?php endif; ?>

<?= $conteudo ?>

</body>
</html>
