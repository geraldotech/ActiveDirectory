<?php
declare(strict_types=1);

namespace App\Controller;

use App\Core\Config;
use App\Core\View;
use App\Model\AdConexao;
use App\Model\GrupoModel;
use App\Model\OuModel;
use App\Model\UsuarioModel;

final class UsuarioController
{
    /** GET / — exibe o formulario com OUs e grupos carregados do AD. */
    public function form(): void
    {
        $erroConexao = null;
        $ous = $grupos = $usuarios = [];

        try {
            $ad = new AdConexao();
            $ous = (new OuModel($ad))->listar();
            $grupos = (new GrupoModel($ad))->listar();
            $usuarios = (new UsuarioModel($ad))->listar();
        } catch (\Throwable $e) {
            $erroConexao = $e->getMessage();
        }

        View::render('usuario/form', [
            'titulo'      => 'Cadastro de Usuário — Active Directory',
            'abaAtiva'    => 'cadastro',
            'ous'         => $ous,
            'grupos'      => $grupos,
            'usuarios'    => $usuarios,
            'erroConexao' => $erroConexao,
            'msg'         => isset($_GET['msg']) ? (string)$_GET['msg'] : '',
            'tipo'        => ($_GET['tipo'] ?? '') === 'ok' ? 'ok' : 'erro',
        ]);
    }

    /** GET /usuarios — lista os usuarios do dominio. */
    public function lista(): void
    {
        $erroConexao = null;
        $usuarios = [];

        try {
            $ad = new AdConexao();
            $usuarios = (new UsuarioModel($ad))->listarDetalhado();
        } catch (\Throwable $e) {
            $erroConexao = $e->getMessage();
        }

        View::render('usuario/lista', [
            'titulo'      => 'Usuários — Active Directory',
            'abaAtiva'    => 'usuarios',
            'usuarios'    => $usuarios,
            'erroConexao' => $erroConexao,
            'msg'         => isset($_GET['msg']) ? (string)$_GET['msg'] : '',
            'tipo'        => ($_GET['tipo'] ?? '') === 'ok' ? 'ok' : 'erro',
        ]);
    }

    /** GET /usuarios/editar?login=x — formulario de edicao. */
    public function editar(): void
    {
        $login = trim($_GET['login'] ?? '');
        if ($login === '') {
            $this->volta('erro', 'Usuario nao informado.', '/usuarios');
        }

        try {
            $ad = new AdConexao();
            $model = new UsuarioModel($ad);
            $u = $model->buscarPorLogin($login);
            $usuarios = $model->listar(); // para o select de gestor
            $grupos = (new GrupoModel($ad))->listar();
            $ous = (new OuModel($ad))->listar();
            $gruposUsuario = $u !== null
                ? array_map('strtolower', $model->gruposDoUsuario($u['dn']))
                : [];
        } catch (\Throwable $e) {
            $this->volta('erro', $e->getMessage(), '/usuarios');
        }

        if ($u === null) {
            $this->volta('erro', "Usuario '{$login}' nao encontrado.", '/usuarios');
        }

        View::render('usuario/editar', [
            'titulo'        => 'Editar Usuário — Active Directory',
            'abaAtiva'      => 'usuarios',
            'u'             => $u,
            'usuarios'      => $usuarios,
            'grupos'        => $grupos,
            'gruposUsuario' => $gruposUsuario,
            'ous'           => $ous,
            'msg'           => isset($_GET['msg']) ? (string)$_GET['msg'] : '',
            'tipo'          => ($_GET['tipo'] ?? '') === 'ok' ? 'ok' : 'erro',
        ]);
    }

    /** POST /usuarios/atualizar — salva a edicao. */
    public function atualizar(): void
    {
        $dn        = trim($_POST['dn'] ?? '');
        $login     = trim($_POST['login'] ?? '');
        $nome      = trim($_POST['nome'] ?? '');
        $sobrenome = trim($_POST['sobrenome'] ?? '');
        $email     = trim($_POST['email'] ?? '');
        $gestorDn  = trim($_POST['gestor'] ?? '');
        $expiraEm  = trim($_POST['expira_em'] ?? '');
        $gruposSel = (array)($_POST['grupos'] ?? []);
        $ouDn      = trim($_POST['ou'] ?? '');

        $baseLower = strtolower((string)Config::get('base_dn'));
        if ($dn === '' || !str_ends_with(strtolower($dn), $baseLower)) {
            $this->volta('erro', 'Usuario invalido.', '/usuarios');
        }
        $voltarPara = '/usuarios/editar?login=' . urlencode($login) . '&';
        foreach ($gruposSel as $g) {
            if (!str_ends_with(strtolower((string)$g), $baseLower)) {
                $this->volta('erro', 'Grupo invalido.', $voltarPara);
            }
        }
        if ($ouDn !== '' && !str_ends_with(strtolower($ouDn), $baseLower)) {
            $this->volta('erro', 'OU invalida.', $voltarPara);
        }
        if ($nome === '' || $sobrenome === '') {
            $this->volta('erro', 'Nome e sobrenome sao obrigatorios.', $voltarPara);
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->volta('erro', 'E-mail invalido.', $voltarPara);
        }
        if ($gestorDn !== '' && !str_ends_with(strtolower($gestorDn), $baseLower)) {
            $this->volta('erro', 'Gestor invalido.', $voltarPara);
        }
        if ($expiraEm !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiraEm)) {
            $this->volta('erro', 'Data de expiracao invalida.', $voltarPara);
        }

        try {
            $ad = new AdConexao();
            $model = new UsuarioModel($ad);
            $model->atualizar($dn, [
                'nome'         => $nome,
                'sobrenome'    => $sobrenome,
                'email'        => $email,
                'cargo'        => trim($_POST['cargo'] ?? ''),
                'departamento' => trim($_POST['departamento'] ?? ''),
                'empresa'      => trim($_POST['empresa'] ?? ''),
                'telefone'     => trim($_POST['telefone'] ?? ''),
                'celular'      => trim($_POST['celular'] ?? ''),
                'matricula'    => trim($_POST['matricula'] ?? ''),
                'descricao'    => trim($_POST['descricao'] ?? ''),
                'gestor_dn'    => $gestorDn,
                'expira_em'    => $expiraEm,
            ]);
            $model->definirGrupos($dn, $gruposSel);
            if ($ouDn !== '') {
                $model->mover($dn, $ouDn); // no-op se ja estiver na OU
            }
            $this->volta('ok', "Usuario {$login} atualizado com sucesso.", '/usuarios');
        } catch (\Throwable $e) {
            $this->volta('erro', $e->getMessage(), $voltarPara);
        }
    }

    /** POST /usuarios/senha — redefine a senha do usuario. */
    public function senha(): void
    {
        $dn     = trim($_POST['dn'] ?? '');
        $login  = trim($_POST['login'] ?? '');
        $senha  = (string)($_POST['senha'] ?? '');
        $trocar = !empty($_POST['trocar_senha']);

        $baseLower = strtolower((string)Config::get('base_dn'));
        if ($dn === '' || !str_ends_with(strtolower($dn), $baseLower)) {
            $this->volta('erro', 'Usuario invalido.', '/usuarios');
        }
        $voltarPara = '/usuarios/editar?login=' . urlencode($login) . '&';
        if (strlen($senha) < 7) {
            $this->volta('erro', 'A nova senha deve ter no minimo 7 caracteres.', $voltarPara);
        }

        try {
            $ad = new AdConexao();
            (new UsuarioModel($ad))->redefinirSenha($dn, $senha, $trocar);
            $this->volta('ok', "Senha de {$login} redefinida com sucesso.", $voltarPara);
        } catch (\Throwable $e) {
            $this->volta('erro', $e->getMessage(), $voltarPara);
        }
    }

    /** POST /usuarios/bloquear — bloqueia ou desbloqueia a conta. */
    public function bloquear(): void
    {
        $dn    = trim($_POST['dn'] ?? '');
        $login = trim($_POST['login'] ?? '');
        $acao  = ($_POST['acao'] ?? '') === 'desbloquear' ? 'desbloquear' : 'bloquear';

        $baseLower = strtolower((string)Config::get('base_dn'));
        if ($dn === '' || !str_ends_with(strtolower($dn), $baseLower)) {
            $this->volta('erro', 'Usuario invalido.', '/usuarios');
        }

        try {
            $ad = new AdConexao();
            (new UsuarioModel($ad))->definirBloqueio($dn, $acao === 'bloquear');
            $this->volta('ok', "Usuario {$login} " . ($acao === 'bloquear' ? 'bloqueado' : 'desbloqueado') . ' com sucesso.', '/usuarios');
        } catch (\Throwable $e) {
            $this->volta('erro', $e->getMessage(), '/usuarios');
        }
    }

    /** POST /usuarios/criar — valida o formulario e cria o usuario. */
    public function criar(): void
    {
        $nome      = trim($_POST['nome'] ?? '');
        $sobrenome = trim($_POST['sobrenome'] ?? '');
        $login     = trim($_POST['login'] ?? '');
        $email     = trim($_POST['email'] ?? '');
        $senha     = (string)($_POST['senha'] ?? '');
        $ouDn      = trim($_POST['ou'] ?? '');
        $grupos    = (array)($_POST['grupos'] ?? []);
        $trocar    = !empty($_POST['trocar_senha']);

        // Campos organizacionais (todos opcionais)
        $cargo        = trim($_POST['cargo'] ?? '');
        $departamento = trim($_POST['departamento'] ?? '');
        $empresa      = trim($_POST['empresa'] ?? '');
        $telefone     = trim($_POST['telefone'] ?? '');
        $celular      = trim($_POST['celular'] ?? '');
        $matricula    = trim($_POST['matricula'] ?? '');
        $descricao    = trim($_POST['descricao'] ?? '');
        $gestorDn     = trim($_POST['gestor'] ?? '');
        $expiraEm     = trim($_POST['expira_em'] ?? '');

        // --- Validacoes ---
        if ($nome === '' || $sobrenome === '' || $login === '' || $senha === '' || $ouDn === '') {
            $this->volta('erro', 'Preencha todos os campos obrigatorios.');
        }
        if (!preg_match('/^[A-Za-z0-9._-]{1,20}$/', $login)) {
            $this->volta('erro', 'Login invalido: use ate 20 caracteres (letras, numeros, ponto, hifen, underline).');
        }
        if (strlen($senha) < 7) {
            $this->volta('erro', 'A senha deve ter no minimo 7 caracteres.');
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->volta('erro', 'E-mail invalido.');
        }

        // OU e grupos precisam pertencer ao dominio configurado
        $baseLower = strtolower((string)Config::get('base_dn'));
        if (!str_ends_with(strtolower($ouDn), $baseLower)) {
            $this->volta('erro', 'OU invalida.');
        }
        foreach ($grupos as $g) {
            if (!str_ends_with(strtolower((string)$g), $baseLower)) {
                $this->volta('erro', 'Grupo invalido.');
            }
        }
        if ($gestorDn !== '' && !str_ends_with(strtolower($gestorDn), $baseLower)) {
            $this->volta('erro', 'Gestor invalido.');
        }
        if ($expiraEm !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiraEm)) {
            $this->volta('erro', 'Data de expiracao invalida.');
        }

        // --- Criacao ---
        try {
            $ad = new AdConexao();
            $dn = (new UsuarioModel($ad))->criar([
                'nome'         => $nome,
                'sobrenome'    => $sobrenome,
                'login'        => $login,
                'email'        => $email,
                'senha'        => $senha,
                'ou_dn'        => $ouDn,
                'grupos'       => $grupos,
                'trocar_senha' => $trocar,
                'cargo'        => $cargo,
                'departamento' => $departamento,
                'empresa'      => $empresa,
                'telefone'     => $telefone,
                'celular'      => $celular,
                'matricula'    => $matricula,
                'descricao'    => $descricao,
                'gestor_dn'    => $gestorDn,
                'expira_em'    => $expiraEm,
            ]);
            $qtd = count($grupos);
            $this->volta('ok', "Usuario {$login} criado com sucesso em {$dn}" . ($qtd ? " e adicionado a {$qtd} grupo(s)." : '.'));
        } catch (\Throwable $e) {
            $this->volta('erro', $e->getMessage());
        }
    }

    private function volta(string $tipo, string $msg, string $para = '/?'): never
    {
        $sep = str_contains($para, '?') ? '' : '?';
        header('Location: ' . base_url($para . $sep . 'tipo=' . $tipo . '&msg=' . urlencode($msg)));
        exit;
    }
}
