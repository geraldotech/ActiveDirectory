<?php
// Configuracao equivalente a conexao validada no aplicativo Python.
return [
    'uri'        => 'ldap://192.168.92.131',
    'base_dn'    => 'DC=local,DC=empresa',
    'bind_dn'    => 'Administrator@local.empresa',
    'bind_pass'  => 'LabAD@Server2026!',
    'upn_suffix' => 'local.empresa',
];
